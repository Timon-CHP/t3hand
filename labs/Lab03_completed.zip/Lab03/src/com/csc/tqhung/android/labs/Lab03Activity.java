package com.csc.tqhung.android.labs;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnLongClickListener;
import android.widget.Button;
import android.widget.EditText;

public class Lab03Activity extends Activity {
    private Button mBtnChange;
	private EditText mEditText;

	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
//        mBtnChange = (Button) findViewById(R.id.mBtnChange);
        mEditText = (EditText) findViewById(R.id.mEditText);
        registerForContextMenu(mEditText);
        
    }
    
	/* (non-Javadoc)
	 * @see android.app.Activity#onCreateOptionsMenu(android.view.Menu)
	 */
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater mi = getMenuInflater();
		mi.inflate(R.menu.optionmenu, menu);
		return super.onCreateOptionsMenu(menu);
	}

	/* (non-Javadoc)
	 * @see android.app.Activity#onMenuItemSelected(int, android.view.MenuItem)
	 */
	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		switch (item.getItemId()) {
		case R.id.mnuItem1:
			Log.i("GCS", "menu item 1 selected");
			break;
		case R.id.g1Item1:
			Log.i("GCS", "Group menu item 1 selected");
			break;
		case R.id.g1Item2:
			Log.i("GCS", "Group menu item 2 selected");
			break;
		default:
			break;
		}
		return super.onMenuItemSelected(featureId, item);
	}

	/* (non-Javadoc)
	 * @see android.app.Activity#onCreateContextMenu(android.view.ContextMenu, android.view.View, android.view.ContextMenu.ContextMenuInfo)
	 */
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {
		MenuInflater mi = getMenuInflater();
		mi.inflate(R.menu.contextmenu, menu);
		super.onCreateContextMenu(menu, v, menuInfo);
	}

	/* (non-Javadoc)
	 * @see android.app.Activity#onContextItemSelected(android.view.MenuItem)
	 */
	@Override
	public boolean onContextItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.contextMnu1:
			Log.i("GCS", "Context item 1 selected");
			break;
		case R.id.contextMnu2:
			Log.i("GCS", "Context item 2 selected");
			break;
		case R.id.contextMnu3:
			Log.i("GCS", "Context item 3 selected");
			break;
		default:
			break;
		}
		return super.onContextItemSelected(item);
	}
    
	
    
}