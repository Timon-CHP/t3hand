/**
 * 
 */
package com.csc.tqhung.android.labs;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.drawable.GradientDrawable.Orientation;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * @author hungtq
 *
 */
public class PhotoAdapter extends BaseAdapter {

	private Integer[] mPhotoPool = {
				R.drawable.android_normal,
				R.drawable.android_waving
            };

	private Context mContext; 
    private ArrayList<Integer> mArPhotoIDs = new ArrayList<Integer>();
	
	/**
	 * 
	 */
	public PhotoAdapter(Context context) {
		mContext = context;
	}

	/* (non-Javadoc)
	 * @see android.widget.Adapter#getCount()
	 */
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mArPhotoIDs.size();
	}

	/* (non-Javadoc)
	 * @see android.widget.Adapter#getItem(int)
	 */
	@Override
	public Object getItem(int arg0) {
		return arg0;
	}

	/* (non-Javadoc)
	 * @see android.widget.Adapter#getItemId(int)
	 */
	@Override
	public long getItemId(int arg0) {
		return (long)arg0;
	}

	/* (non-Javadoc)
	 * @see android.widget.Adapter#getView(int, android.view.View, android.view.ViewGroup)
	 */
	@Override
	public View getView(int arg0, View arg1, ViewGroup arg2) {
		
		LinearLayout ll = new LinearLayout(mContext);
		ll.setLayoutParams(new AbsListView.LayoutParams(LayoutParams.FILL_PARENT,
                LayoutParams.WRAP_CONTENT));
		ll.setOrientation(ll.HORIZONTAL);
		
		ImageView iv = new ImageView(mContext);
        iv.setImageResource(mArPhotoIDs.get(arg0));
        iv.setAdjustViewBounds(true);
        
        iv.setLayoutParams(new AbsListView.LayoutParams(LayoutParams.WRAP_CONTENT,
                LayoutParams.WRAP_CONTENT));
        ll.addView(iv);
        
        TextView tv = new TextView(mContext);
        tv.setText("Item " + String.valueOf(mArPhotoIDs.size() + 1));
        ll.addView(tv);
                
        return ll;
	}
	
	public void clearPhotos() {
        mArPhotoIDs.clear();
        notifyDataSetChanged();
    }
    
    public void addPhotos() {
        int whichPhoto = (int)Math.round(Math.random() * (mPhotoPool.length - 1));
        int newPhoto = mPhotoPool[whichPhoto];
        mArPhotoIDs.add(newPhoto);
        notifyDataSetChanged();
    }

}
