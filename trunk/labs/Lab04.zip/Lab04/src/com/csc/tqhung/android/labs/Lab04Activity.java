package com.csc.tqhung.android.labs;

import android.app.Activity;
import android.app.LauncherActivity.ListItem;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class Lab04Activity extends Activity {
    private ListView mList;
    private String[] mArrStr = {
    	"Thang 01", "Thang 02", "Thang 03",
    	"Thang 04", "Thang 05", "Thang 06",
    	"Thang 07", "Thang 08", "Thang 09",
    	"Thang 10", "Thang 11", "Thang 12", "Customized List"
    };
	protected Intent intentlist;

	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        mList = (ListView) findViewById(R.id.listView1);
        mList.setAdapter(new ArrayAdapter<String>(this, 
        		android.R.layout.simple_list_item_1, mArrStr));
        
        mList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				String strItem = ((TextView)arg1).getText().toString();
				
				if (mArrStr[mArrStr.length - 1].equals(strItem)) {
//					Toast.makeText(Lab04Activity.this, 
//							strItem,
//							500).show();
					if (intentlist == null) {
						intentlist = new Intent(Lab04Activity.this, MyListView.class);	
					}
					startActivity(intentlist);
					
				}else {
					Toast.makeText(Lab04Activity.this, 
							strItem,
							500).show();
				}
			}
		});
        
//        mList.setOnItemSelectedListener(new OnItemSelectedListener() {
//
//			@Override
//			public void onItemSelected(AdapterView<?> arg0, View arg1,
//					int arg2, long arg3) {
//				Toast.makeText(Lab04Activity.this, 
//						((TextView)arg1).getText(),
//						500).show();
//			}
//
//			@Override
//			public void onNothingSelected(AdapterView<?> arg0) {
//				Toast.makeText(Lab04Activity.this, 
//						"aexcaw",
//						500).show();
//			}
//		});
    }
}