/**
 * 
 */
package com.csc.tqhung.android.labs;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

/**
 * @author hungtq
 *
 */
public class MyListView extends ListActivity {

	private Button mBtnAdd;
	private Button mBtnClear;
	private OnClickListener mOnClick;
	private PhotoAdapter mAdapter;

	/* (non-Javadoc)
	 * @see android.app.Activity#onCreate(android.os.Bundle)
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.customlist);
		
		mBtnAdd = (Button) findViewById(R.id.add);
		mBtnClear = (Button) findViewById(R.id.clear);
		mOnClick = new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				if (v.equals(mBtnAdd)) {
					Toast.makeText(MyListView.this, 
							"added a new itme",
							100).show();
					mAdapter.addPhotos();
				} else if (v.equals(mBtnClear)) {
					Toast.makeText(MyListView.this, 
							"removed all",
							100).show();
					mAdapter.clearPhotos();
				}
			}
		};
		mBtnAdd.setOnClickListener(mOnClick);
		mBtnClear.setOnClickListener(mOnClick);
		mAdapter = new PhotoAdapter(this);
        setListAdapter(mAdapter);
	}


	/* (non-Javadoc)
	 * @see android.app.ListActivity#onListItemClick(android.widget.ListView, android.view.View, int, long)
	 */
	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		// TODO Auto-generated method stub
		super.onListItemClick(l, v, position, id);
	}

}
