package com.csc.tqhung.android.labs;

import java.util.ArrayList;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.MemoryInfo;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Bundle;
import android.provider.Settings;
import android.provider.Settings.SettingNotFoundException;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class Lab10_DeviceInfomationActivity extends Activity {
	private static final int MAX_BRIGHTNESS = 245;
	private ArrayList<String> mArrayInfo;
	private ListView mList;
	private ArrayAdapter<String> mArAdapter;
	
	//For Battery information
	private IntentFilter mBatteryIntentFilter;
	private BroadcastReceiver mBatteryReceiver = new BroadcastReceiver() {
		
		@Override
		public void onReceive(Context context, Intent intent) {
			if (intent.getAction().equals(Intent.ACTION_BATTERY_CHANGED)){
				mArAdapter.add("Battery Level: "
						+ String.valueOf(intent.getIntExtra("level", 0)) + "%");
				mArAdapter.add("Battery Voltage: "
						+ String.valueOf((float)intent.getIntExtra("voltage", 0)/1000) + "V");
				mArAdapter.add("Battery Temperature: "
						+ String.valueOf((float)intent.getIntExtra("temperature", 0)/10) + "c");
				mArAdapter.add("Battery Technology: " + intent.getStringExtra("technology"));
				
				int status = intent.getIntExtra("status", BatteryManager.BATTERY_STATUS_UNKNOWN);
				String strStatus;
				if (status == BatteryManager.BATTERY_STATUS_CHARGING){
					strStatus = "Charging";
				} else if (status == BatteryManager.BATTERY_STATUS_DISCHARGING){
					strStatus = "Dis-charging";
				} else if (status == BatteryManager.BATTERY_STATUS_NOT_CHARGING){
					strStatus = "Not charging";
				} else if (status == BatteryManager.BATTERY_STATUS_FULL){
					strStatus = "Full";
				} else {
					strStatus = "Unknown";
				}
				mArAdapter.add("Battery Status: " + strStatus);
				
				int health = intent.getIntExtra("health", BatteryManager.BATTERY_HEALTH_UNKNOWN);
				String strHealth;
				if (health == BatteryManager.BATTERY_HEALTH_GOOD){
					strHealth = "Good";
				} else if (health == BatteryManager.BATTERY_HEALTH_OVERHEAT){
					strHealth = "Over Heat";
				} else if (health == BatteryManager.BATTERY_HEALTH_DEAD){
					strHealth = "Dead";
				} else if (health == BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE){
					strHealth = "Over Voltage";
				} else if (health == BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE){
					strHealth = "Unspecified Failure";
				} else{
					strHealth = "Unknown";
				}
				mArAdapter.add("Battery Health: " + strHealth);
			}
		}
	};

	/** Called when the activity is first created. */

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		mArrayInfo = new ArrayList<String>();
		mArAdapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1, mArrayInfo);
		mList = (ListView) findViewById(R.id.mList);
		mList.setAdapter(mArAdapter);
		
		//For reading battery information
		mBatteryIntentFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
		
		doLoadInfomation();
	}

	/* (non-Javadoc)
	 * @see android.app.Activity#onPause()
	 */
	@Override
	protected void onPause() {
		this.unregisterReceiver(mBatteryReceiver);
		super.onPause();
	}

	/* (non-Javadoc)
	 * @see android.app.Activity#onResume()
	 */
	@Override
	protected void onResume() {
		super.onResume();
		this.registerReceiver(mBatteryReceiver, mBatteryIntentFilter);
	}

	private void doLoadInfomation() {

		// Brightness
		mArAdapter.add(String.format("Brightness value: %1d", getBrighness()));

		// Available memory
		mArAdapter.add(String.format("Total memory: %1d", getAvailableMemory()));
		
		//Get MSISDN (GSM - SIM)
		mArAdapter.add(String.format("MSISDN: %1s", getMSISDN()));
		
		//Get IMEI
		mArAdapter.add(String.format("IMEI: %1s", getIMEI()));
		
		//Get API version
		mArAdapter.add(String.format("API version: %1s" , getAPIVersion()));
		mArAdapter.notifyDataSetChanged();
	}

	private String getAPIVersion() {
		return android.os.Build.VERSION.RELEASE;
	}

	private String getMSISDN() {
		StringBuffer sb = new StringBuffer();
		TelephonyManager tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
		sb.append(tm.getLine1Number());
//		tm.getDeviceId();
//		tm.getDeviceSoftwareVersion();
//		tm.getNetworkType();
		sb.append(tm.getDeviceId());
		return sb.toString();
	}
	
	private String getIMEI() {
		StringBuffer sb = new StringBuffer();
		TelephonyManager tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
		sb.append(tm.getDeviceId());
		return sb.toString();
	}

	private long getAvailableMemory() {
		long result = 0;
		ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
		MemoryInfo minfo = new ActivityManager.MemoryInfo();
		am.getMemoryInfo(minfo);
		if (minfo != null) {
			result = minfo.availMem;
		}
		return result;
	}

	private int getBrighness() {
		int result = MAX_BRIGHTNESS / 2;
		try {
			result = Settings.System.getInt(getApplicationContext()
					.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS);
		} catch (SettingNotFoundException snfe) {
			result = MAX_BRIGHTNESS;
		}
		return result;
	}

}