package com.csc.tqhung.android.labs;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.DefaultClientConnection;
import org.apache.http.util.EntityUtils;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

public class Lab08NetworkAsyncTaskActivity extends Activity {
    private static final String LOG_TAG = "TTTH";
	private EditText mInputURL;
	private EditText mOutputContent;
	private ImageView mImageView;

	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        mInputURL = (EditText) findViewById(R.id.edURL);
        mOutputContent = (EditText) findViewById(R.id.edContent);
        mImageView = (ImageView) findViewById(R.id.mImageView);
        
    }

	public void onClick(View view) {
		if (view.getId() == R.id.button1) {
			new StringLoaderTask().execute(mInputURL.getText().toString());
		}else if (view.getId() == R.id.button2) {
			new StringLoaderTask().execute("http://www.ietf.org/id/draft-zyp-json-schema-04.txt");
		}else if (view.getId() == R.id.button3) {
			new BitmapLoaderTask().execute("http://glamgirlcars.com/wp-content/uploads/2008/10/carloan.jpg");
		}else if (view.getId() == R.id.mBtnClear) {
			mOutputContent.setText("");
			mImageView.setImageBitmap(null);
		}
	}

	private String doGet(String prStrURL) {
		StringBuffer result = new StringBuffer();
		try {
			HttpClient httpclient = (HttpClient) new DefaultHttpClient();
			HttpGet getobj = new HttpGet(prStrURL);
			HttpResponse response;
			response = httpclient.execute(getobj);
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity anEntity = response.getEntity(); 

				Header aHeader = anEntity.getContentType();
				
				result.append(aHeader.getName()).append(": ");
				result.append(aHeader.getValue()).append("\n");
				
				if (aHeader.getValue().contains("image/")) {
					//should show image instead.
					Bitmap aBitmap = new BitmapDrawable(anEntity.getContent()).getBitmap();
					mImageView.setImageBitmap(aBitmap);
					
				}else if (aHeader.getValue().equals("text/")) {
					result.append(EntityUtils.toString(anEntity));
				} 
				
			}
		} catch (ClientProtocolException e) {
			result.append("Falied at ClientProtocolException with error: " + e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			result.append("Falied at IOException with error: " + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			result.append("Falied at Exception with error: " + e.getMessage());
			e.printStackTrace();
		}
		return result.toString();
	}

	private class BitmapLoaderTask extends AsyncTask<String, Integer, Bitmap>{

		@Override
		protected Bitmap doInBackground(String... params) {
			Bitmap result = null;
			if (params.length <= 0) {
				return null;
			}
			for (int i = 0; i < params.length; i++) {
				String aURL = params[i];
				try {
					HttpClient httpclient = (HttpClient) new DefaultHttpClient();
					HttpGet getobj = new HttpGet(aURL);
					HttpResponse response;
					response = httpclient.execute(getobj);
					if (response.getStatusLine().getStatusCode() == 200) {
						HttpEntity anEntity = response.getEntity(); 
						Header aHeader = anEntity.getContentType();
						if (aHeader.getValue().contains("image/")) {
							 result = new BitmapDrawable(anEntity.getContent()).getBitmap();
						}
					}
				} catch (ClientProtocolException e) {
					Log.e(LOG_TAG, "Falied at ClientProtocolException with error: " + e.getMessage());
					e.printStackTrace();
				} catch (IOException e) {
					Log.e(LOG_TAG, "Falied at IOException with error: " + e.getMessage());
					e.printStackTrace();
				} catch (Exception e) {
					Log.e(LOG_TAG, "Falied at Exception with error: " + e.getMessage());
					e.printStackTrace();
				}
			}
			return result;
		}

		@Override
		protected void onPostExecute(Bitmap result) {
			if (result != null) {
				mImageView.setImageBitmap(result);
			}
		}
	}
	
	private class StringLoaderTask extends AsyncTask<String, Integer, String>{

		@Override
		protected String doInBackground(String... params) {
			String result = null;
			if (params.length <= 0) {
				return null;
			}
			for (int i = 0; i < params.length; i++) {
				String aURL = params[i];
				try {
					HttpClient httpclient = (HttpClient) new DefaultHttpClient();
					HttpGet getobj = new HttpGet(aURL);
					HttpResponse response = httpclient.execute(getobj);
					if (response.getStatusLine().getStatusCode() == 200) {
						HttpEntity anEntity = response.getEntity(); 
						Header aHeader = anEntity.getContentType();
						if (aHeader.getValue().contains("text/")) {
							result = EntityUtils.toString(anEntity);
						}
					}
				} catch (ClientProtocolException e) {
					Log.e(LOG_TAG, "Falied at ClientProtocolException with error: " + e.getMessage());
					e.printStackTrace();
				} catch (IOException e) {
					Log.e(LOG_TAG, "Falied at IOException with error: " + e.getMessage());
					e.printStackTrace();
				} catch (Exception e) {
					Log.e(LOG_TAG, "Falied at Exception with error: " + e.getMessage());
					e.printStackTrace();
				}
			}
			return result;
		}

		@Override
		protected void onPostExecute(String result) {
			if (result != null && result.length() > 0) {
				mOutputContent.setText(result);
			}
		}
		
	}
}