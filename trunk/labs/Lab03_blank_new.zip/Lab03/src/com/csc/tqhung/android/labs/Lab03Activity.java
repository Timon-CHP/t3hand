package com.csc.tqhung.android.labs;

import android.app.Activity;
import android.os.Bundle;

public class Lab03Activity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
}