package com.csc.tqhung.android.labs;
import java.io.FileInputStream;
import java.io.IOException;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.SoundPool;
import android.media.SoundPool.OnLoadCompleteListener;
import android.net.Uri;
import android.util.Log;

/**
 * @author hungtq
 * 
 */
public class SoundManager {
	public static final int MODE_MEDIAPLAYER = 0; // play by MediaPlayer
	public static final int MODE_SOUNDPOOL = 1; // play by SoundPool

	private static SoundManager mSoundManager = null;
	private Context mContext = null;
	private int mPlayMode;

	// MediaPlayer fields
	private MediaPlayer mMediaPlayer;
	private String packageName = "com.csc.tqhung.android.labs";
	
	// SoundPool fields
	private SoundPool mSoundPool;
	private int mPlayingID;
	private int mStreamID;

	public static SoundManager getInstance(Context context) {
		if (mSoundManager == null) {
			mSoundManager = new SoundManager();
		}
		mSoundManager.setContext(context);
		return mSoundManager;
	}

	private SoundManager() {
		mPlayMode = MODE_MEDIAPLAYER;
		// mPlayMode = MODE_SOUNDPOOL;
	}

	public void setContext(Context context) {
		mContext = context;
	}

	public void setPlayMode(int playMode) {
		switch (playMode) {
		case MODE_SOUNDPOOL:
			mPlayMode = MODE_SOUNDPOOL;
			break;
		case MODE_MEDIAPLAYER:
		default:
			mPlayMode = MODE_MEDIAPLAYER;
			break;
		}
	}

	public void play(int resID) {
		switch (mPlayMode) {
		case MODE_MEDIAPLAYER:
			playByMediaPlayer(resID);
			break;
		case MODE_SOUNDPOOL:
			playBySoundPool(resID);
			break;
		default:
			break;
		}
	}

	public void play(String filePath) {
		if (filePath == null || filePath.length() <= 0) {
			return;
		}
		switch (mPlayMode) {
		case MODE_MEDIAPLAYER:
			playByMediaPlayer(filePath);
			break;
		case MODE_SOUNDPOOL:
			playBySoundPool(filePath);
			break;
		default:
			break;
		}
	}

	public void stop() {
		switch (mPlayMode) {
		case MODE_MEDIAPLAYER:
			stopByMediaPlayer();
			break;
		case MODE_SOUNDPOOL:
			stopBySoundPool();
			break;
		default:
			break;
		}
	}

	private void playByMediaPlayer(int resID) {
		try {
			if (mMediaPlayer == null) {
				mMediaPlayer = new MediaPlayer();
				mMediaPlayer.setOnPreparedListener(new OnPreparedListener() {
					@Override
					public void onPrepared(MediaPlayer mp) {
						// TODO On Audio stream prepared
						Log.i(Lab09_SoundActivity.LOG_TAG, "onPrepared");
						mMediaPlayer.start();
					}
				});
				mMediaPlayer
						.setOnCompletionListener(new OnCompletionListener() {
							@Override
							public void onCompletion(MediaPlayer mp) {
								// TODO On play completed
								Log.i(Lab09_SoundActivity.LOG_TAG,
										"onCompletion");
							}
						});
			}
			mMediaPlayer.reset();
			mMediaPlayer.setDataSource(mContext, Uri.parse("android.resource://"+ packageName  + "/" + resID));
			mMediaPlayer.prepareAsync();
		} catch (IOException e) {
			Log.e(Lab09_SoundActivity.LOG_TAG, e.getMessage());
		}
	}
	
	private void playByMediaPlayer(String filePath) {
		try {
			FileInputStream fis = new FileInputStream(filePath);
			if (mMediaPlayer == null) {
				mMediaPlayer = new MediaPlayer();
				mMediaPlayer.setOnPreparedListener(new OnPreparedListener() {
					@Override
					public void onPrepared(MediaPlayer mp) {
						// TODO On Audio stream prepared
						Log.i(Lab09_SoundActivity.LOG_TAG, "onPrepared");
						mMediaPlayer.start();
					}
				});
				mMediaPlayer
						.setOnCompletionListener(new OnCompletionListener() {
							@Override
							public void onCompletion(MediaPlayer mp) {
								// TODO On play completed
								Log.i(Lab09_SoundActivity.LOG_TAG,
										"onCompletion");
							}
						});
			}
			mMediaPlayer.reset();
			mMediaPlayer.setDataSource(fis.getFD());
			mMediaPlayer.prepareAsync();
		} catch (IOException e) {
			Log.e(Lab09_SoundActivity.LOG_TAG, e.getMessage());
		}
	}

	private void stopByMediaPlayer() {
		if (mMediaPlayer != null) {
			if (mMediaPlayer.isPlaying()) {
				mMediaPlayer.stop();
			}
			mMediaPlayer.reset();
			mMediaPlayer.release();
			mMediaPlayer = null;
		}
	}

	private void playBySoundPool(int resID) {
		if (mSoundPool == null) {
			mSoundPool = new SoundPool(1, AudioManager.STREAM_MUSIC, 0 );  
			mSoundPool.setOnLoadCompleteListener(new OnLoadCompleteListener() {
				@Override
				public void onLoadComplete(SoundPool soundPool, int sampleId, int status) {
					mStreamID = mSoundPool.play(mPlayingID, 1, 1, 0, 0, 1f);
				}
			});
		}
		mPlayingID = mSoundPool.load (mContext, resID, 1);
	}

	private void playBySoundPool(String filePath) {
		if (mSoundPool == null) {
			mSoundPool = new SoundPool(1, AudioManager.STREAM_MUSIC, 0 );  
			mSoundPool.setOnLoadCompleteListener(new OnLoadCompleteListener() {
				@Override
				public void onLoadComplete(SoundPool soundPool, int sampleId, int status) {
					mStreamID = mSoundPool.play(mPlayingID, 1, 1, 0, 0, 1f);
				}
			});
		}
		mPlayingID = mSoundPool.load ( filePath, 1 );
	}
	
	private void stopBySoundPool() {
		if (mSoundPool != null) {
			mSoundPool.stop(mStreamID);
		}
		mSoundPool.release();
		mSoundPool = null;
	}
}
