package com.csc.tqhung.android.labs;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class Lab09_SoundActivity extends Activity {
	public static final String LOG_TAG = "TTTH";
	private SoundManager mSM;
	private EditText mEditText;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		mSM = SoundManager.getInstance(this);
		
		mEditText = (EditText) findViewById(R.id.mEdText);
	}

	public void onClick(View view) {
		if (view.getId() == R.id.mbtnPlay) {
			Log.i(LOG_TAG, "onPlay by MEDIAPLAYER");
			mSM.stop();
			mSM.setPlayMode(SoundManager.MODE_MEDIAPLAYER);
			mSM.play(R.raw.congainhocuaba);
		} else if (view.getId() == R.id.mbtnStop) {
			Log.i(LOG_TAG, "onStop");
			mSM.stop();
		}else if (view.getId() == R.id.button1) {
			mSM.stop();
			mSM.setPlayMode(SoundManager.MODE_SOUNDPOOL);
			mSM.play(R.raw.longamr);
			Log.i(LOG_TAG, "onPlay by SOUNDPOOL");
		}else if (view.getId() == R.id.button3) {
			mSM.stop();
			String filepath = mEditText.getText().toString();
			Log.i(LOG_TAG, "onPLAY file: " + filepath + " by MEDIAPLAYER");
			mSM.setPlayMode(SoundManager.MODE_MEDIAPLAYER);
			mSM.play(filepath);
		}
	}
}