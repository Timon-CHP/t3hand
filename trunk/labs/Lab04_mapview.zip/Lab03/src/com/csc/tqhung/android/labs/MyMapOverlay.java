/**
 * 
 */
package com.csc.tqhung.android.labs;

import java.util.ArrayList;

import android.graphics.drawable.Drawable;
import android.view.MotionEvent;
import android.widget.Toast;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;
import com.google.android.maps.Projection;

/**
 * @author hungtq
 *
 */
public class MyMapOverlay extends ItemizedOverlay {

	private ArrayList<OverlayItem> mArrOlay = new ArrayList<OverlayItem>();
	
	/**
	 * @param defaultMarker
	 */
	public MyMapOverlay(Drawable defaultMarker) {
		super(boundCenterBottom(defaultMarker));
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see com.google.android.maps.ItemizedOverlay#createItem(int)
	 */
	@Override
	protected OverlayItem createItem(int i) {
		return mArrOlay.get(i);
	}

	public void addOverlay(OverlayItem olItem) {
		mArrOlay.add(olItem);
		populate();
	}
	
	/* (non-Javadoc)
	 * @see com.google.android.maps.ItemizedOverlay#size()
	 */
	@Override
	public int size() {
		return mArrOlay.size();
	}

	/* (non-Javadoc)
	 * @see com.google.android.maps.ItemizedOverlay#onTouchEvent(android.view.MotionEvent, com.google.android.maps.MapView)
	 */
	@Override
	public boolean onTouchEvent(MotionEvent event, MapView mapView) {
		Projection mapPrj = mapView.getProjection();
		GeoPoint gp = mapPrj.fromPixels((int)event.getX(), (int)event.getY());
		Toast.makeText(mapView.getContext(), 
//				"touched at: (" +
//				String.valueOf(event.getX()) + ", " + 
//				String.valueOf(event.getY())+ ") and in Map is: " +
				"(" + 
				String.valueOf(gp.getLatitudeE6()) + ", " +
				String.valueOf(gp.getLongitudeE6()) + ").", 1000).show();
		
		OverlayItem overlayitem = new OverlayItem(gp, "", "");
		addOverlay(overlayitem);
		return super.onTouchEvent(event, mapView);
	}
	
	
//	/* (non-Javadoc)
//	 * @see android.app.Activity#onTouchEvent(android.view.MotionEvent)
//	 */
//	public boolean onTouchEvent() {
//		

//		return super.onTouchEvent(event);
//	}
}
