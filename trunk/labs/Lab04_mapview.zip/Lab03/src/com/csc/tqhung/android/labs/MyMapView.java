/**
 * 
 */
package com.csc.tqhung.android.labs;

import java.util.List;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.Toast;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;
import com.google.android.maps.Projection;

/**
 * @author hungtq
 *
 */
public class MyMapView extends MapActivity {

	
	
	private MapView mMapView;
	List<Overlay> mapOverlays;
	Drawable drawable;
	MyMapOverlay itemizedOverlay;

	/* (non-Javadoc)
	 * @see com.google.android.maps.MapActivity#onCreate(android.os.Bundle)
	 */
	@Override
	protected void onCreate(Bundle arg0) {
		// TODO Auto-generated method stub
		super.onCreate(arg0);
		setContentView(R.layout.layoutmap);
		mMapView = (MapView) findViewById(R.id.mymap);
		mMapView.setBuiltInZoomControls(true);
		
		mapOverlays = mMapView.getOverlays();
		drawable = getResources().getDrawable(R.drawable.iconmarker);
		itemizedOverlay = new MyMapOverlay(drawable);
		
		GeoPoint point = new GeoPoint(10763406, 106675617);
		OverlayItem overlayitem = new OverlayItem(point, "", "");
		itemizedOverlay.addOverlay(overlayitem);
		mapOverlays.add(itemizedOverlay);
		
		mMapView.getController().zoomToSpan(10763406, 106675617);
		
	}

	/* (non-Javadoc)
	 * @see com.google.android.maps.MapActivity#isRouteDisplayed()
	 */
	@Override
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}



	
}
