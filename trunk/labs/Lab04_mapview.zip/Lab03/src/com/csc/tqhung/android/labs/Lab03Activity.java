package com.csc.tqhung.android.labs;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.widget.RadioGroup.OnCheckedChangeListener;

public class Lab03Activity extends Activity {
    private RadioButton mrdShow;
	private RadioButton mrdHide;
	private OnCheckedChangeListener mrgCheckChange;
	private ImageView mImageV;
	private RadioGroup mRGroup;
	private Button mBtn;
	private OnClickListener mBtnClick;

	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        mrdShow = (RadioButton) findViewById(R.id.radioButton1);
        mrdHide = (RadioButton) findViewById(R.id.radioButton2);
        mImageV = (ImageView) findViewById(R.id.imageView1);
        mrgCheckChange = new RadioGroup.OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				if (R.id.radioButton1 == checkedId) {
					mImageV.setVisibility(View.VISIBLE);
				}else if (R.id.radioButton2 == checkedId) {
					mImageV.setVisibility(View.GONE);
				}
			}
		};
		mRGroup = (RadioGroup) findViewById(R.id.rdGroup);
		mRGroup.setOnCheckedChangeListener(mrgCheckChange);
		
		mBtn = (Button) findViewById(R.id.button1);
		mBtnClick = new View.OnClickListener() {
			public void onClick(View v) {
				showMapView();
			}
		};
		mBtn.setOnClickListener(mBtnClick);
    }

	protected void showMapView() {
		Intent i = new Intent(this, MyMapView.class);
		startActivity(i);
	}
}