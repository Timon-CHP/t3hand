package com.csc.tqhung.android.labs;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

public class Lab05PreferencesActivity extends Activity {
    private static final String PREFERENCES_NAME = "prefconf";
	private TextView mTextv;

	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        mTextv = (TextView) findViewById(R.id.status);
        SharedPreferences settings = getSharedPreferences(PREFERENCES_NAME, 0);
        if(settings.getBoolean("TextViewMode", false))
        {
        	mTextv.setText("Get preferences true");
        }
        else
        {
        	mTextv.setText("Get preferences false");
        }
    }

	/* (non-Javadoc)
	 * @see android.app.Activity#onPause()
	 */
	@Override
	protected void onPause() {
		SharedPreferences settings = getSharedPreferences(PREFERENCES_NAME, 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putBoolean("TextViewMode", !settings.getBoolean("TextViewMode", false));
        // Commit the edits!
        editor.commit();

		super.onPause();
	}

	/* (non-Javadoc)
	 * @see android.app.Activity#onResume()
	 */
	@Override
	protected void onResume() {
		SharedPreferences settings = getSharedPreferences(PREFERENCES_NAME, 0);
        if(settings.getBoolean("TextViewMode", false))
        {
        	mTextv.setText("Get preferences true");
        }
        else
        {
        	mTextv.setText("Get preferences false");
        }
		super.onResume();
	}
    
    
}